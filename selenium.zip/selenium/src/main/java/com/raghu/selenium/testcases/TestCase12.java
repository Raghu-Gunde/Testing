package com.raghu.selenium.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase12 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/signup");
		 WebDriverWait wait = new WebDriverWait(driver, 15);
         wait.until(ExpectedConditions.titleContains("Gmail"));
         wait.until(ExpectedConditions.titleIs("Gmail"));
	}

}
