package com.raghu.selenium.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase13 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.fedex.com/sg/");
		
		driver.findElement(By.linkText("Sign Up/Log In")).click();
		
		if(driver.findElement(By.name("user")).isDisplayed())
		{
			System.out.println("The user textbox is present");
		}
		if(driver.findElement(By.name("pwd")).isDisplayed())
		{
			System.out.println("The password textbox is present");
		}
		
		System.out.println(driver.findElement(By.name("user")).getText());
		System.out.println(driver.findElement(By.name("pwd")).getText());
		driver.findElement(By.name("user")).sendKeys("raghu");
		driver.findElement(By.name("pwd")).sendKeys("Raghu@1047");
		
		if(!driver.findElement(By.cssSelector("input[value='rememberme']")).isEnabled())
			driver.findElement(By.cssSelector("input[value='rememberme']")).click();
		Thread.sleep(2000);
		driver.findElement(By.tagName("button")).submit();
		driver.quit();
	}

}
