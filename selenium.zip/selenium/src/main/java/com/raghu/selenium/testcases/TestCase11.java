package com.raghu.selenium.testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public abstract class TestCase11 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/signup");
		driver.findElement(By.linkText("Terms")).click();
		driver.findElement(By.linkText("Privacy")).click();

		for(String winHandle : driver.getWindowHandles()){
			driver.switchTo().window(winHandle);
			List<WebElement> links= driver.findElements(By.tagName("a")); 
			int k = links.size();
			System.out.println("Total no of links Available: " +k);
			System.out.println("List of links Available: ");
			System.out.println(driver.getTitle());
			for(int i=0;i<k;i++)
			{
				if(links.get(i).getAttribute("href").contains("google"))
				{
					String link = links.get(i).getAttribute("href");
					System.out.println(link);
				}   
			}
		} 

	}

}
