package com.raghu.selenium.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase16 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\graghu\\Downloads\\HTML Pages\\popup2.html");
		driver.findElement(By.tagName("button")).click();
		String mes = driver.switchTo().alert().getText();
        System.out.println(mes);
        driver.switchTo().alert().accept();
        System.out.println(driver.findElement(By.xpath("//p[@id='confirmdemo']")).getText());
	}

}
