package com.raghu.selenium.testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase18 {

	public static void main(String[] args) {
		String loc="";
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get(" http://newtours.demoaut.com/");
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.xpath("//input[@value='Login' and @name='login']")).click();
		List<WebElement> depList=new Select(driver.findElement(By.xpath("//select[@name='fromPort']"))).getOptions();
		for(int i=0;i<depList.size();i++)
		{
			if(depList.get(i).getText().equalsIgnoreCase("India"))
			{
				loc="India";
				break;
			}
			else
				continue;
				
		}
		if(loc.equalsIgnoreCase("India"))
			System.out.println("India is present in departure list");
		else
			System.out.println("India is not present in departure list");

	}

}
