package com.raghu.selenium.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCase15 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\graghu\\Downloads\\HTML Pages\\popup1.html");
		driver.findElement(By.tagName("button")).click();
		driver.switchTo().alert().accept();
		driver.findElement(By.tagName("button")).click();
		driver.switchTo().alert().dismiss();
	}

}
